from pymongo import MongoClient


class Mongo_writer:
    def __init__(self):
        self.connect = MongoClient()
        self.db = self.connect['local-database']
        self.db = self.db['test-collecction']

    def read_viewed(self, main_id):
        return {
            i['view_id'] for i in self.db.posts.find({'main_id': main_id})
        }

    def write_viewed(self, main_id, data):
        for i in data:
            self.db.posts.insert_one(
                {
                    'main_id': main_id,
                    'view_id': i['id'],
                    'photos': i['photos']
                }
            )
